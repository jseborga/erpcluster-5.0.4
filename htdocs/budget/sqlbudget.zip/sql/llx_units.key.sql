ALTER TABLE llx_units ADD UNIQUE unit_unique (entity, fk_type, ref);
