ALTER TABLE llx_pu_formulas_det ADD UNIQUE INDEX uk_pformulasdet_entity_refformula_sequen(entity,ref_formula,sequen);
