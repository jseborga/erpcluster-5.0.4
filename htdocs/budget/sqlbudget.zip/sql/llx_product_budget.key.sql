ALTER TABLE llx_product_budget DROP INDEX uk_budget;
ALTER TABLE llx_product_budget ADD UNIQUE uk_budget (fk_budget, ref, code_structure);
ALTER TABLE llx_product_budget ADD UNIQUE uk_unique_label ( fk_budget, code_structure, label);
ALTER TABLE llx_product_budget ADD percent_prod DOUBLE NOT NULL DEFAULT '100' AFTER quant;
ALTER TABLE llx_product_budget ADD amount_noprod DOUBLE NOT NULL DEFAULT '0' AFTER percent_prod;