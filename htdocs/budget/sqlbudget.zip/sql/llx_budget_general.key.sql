ALTER TABLE llx_budget_general ADD UNIQUE uk_unique (fk_budget);
ALTER TABLE llx_budget_general CHANGE second_currency second_currency VARCHAR( 10 ) NULL DEFAULT NULL;