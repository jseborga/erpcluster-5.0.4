ALTER TABLE llx_product_group ADD UNIQUE (ref);
