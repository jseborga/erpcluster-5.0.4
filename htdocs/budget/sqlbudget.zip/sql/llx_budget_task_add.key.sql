ALTER TABLE llx_budget_task_add ADD UNIQUE uk_unique (fk_budget_task);
ALTER TABLE llx_budget_task_add ADD complementary VARCHAR( 1 ) NOT NULL DEFAULT '0' AFTER fk_type;
ALTER TABLE llx_budget_task_add CHANGE unit_budget double NOT NULL DEFAULT '0';
ALTER TABLE llx_budget_task_add ADD total_amount DOUBLE NOT NULL DEFAULT '0' AFTER unit_amount;