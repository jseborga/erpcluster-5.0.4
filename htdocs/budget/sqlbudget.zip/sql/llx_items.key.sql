ALTER TABLE llx_items ADD UNIQUE uk_unique(entity, ref);
