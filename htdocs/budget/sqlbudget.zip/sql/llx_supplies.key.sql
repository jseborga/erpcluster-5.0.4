ALTER TABLE llx_supplies ADD UNIQUE unique (fk_product_group, fk_product);
