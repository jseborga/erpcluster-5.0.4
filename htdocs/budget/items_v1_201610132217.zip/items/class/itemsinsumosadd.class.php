<?php
require_once DOL_DOCUMENT_ROOT.'/priceunits/items/class/itemsinsumos.class.php';

class Itemsinsumosadd extends Itemsinsumos
{
	
}
?>