CREATE TABLE llx_items (
  rowid integer AUTO_INCREMENT PRIMARY KEY,
  entity integer NOT NULL,
  ref varchar(30) NOT NULL,
  ref_ext varchar(30) NULL,
  fk_user_create integer NOT NULL,
  fk_user_mod integer NOT NULL,
  fk_type_item integer NOT NULL,
  detail varchar(100) NULL DEFAULT '',
  fk_unit integer NOT NULL,
  especification varchar(50) DEFAULT NULL,
  plane varchar(50) DEFAULT NULL,
  quant double(24,5) DEFAULT 0 NULL,
  amount double(24,5) DEFAULT 0 NULL,
  date_create date NOT NULL,
  date_mod date NULL,
  tms timestamp,
  status tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB;

