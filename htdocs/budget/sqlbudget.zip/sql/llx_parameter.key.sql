ALTER TABLE llx_parameter ADD UNIQUE unique (fk_user_create);
