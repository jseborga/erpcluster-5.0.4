ALTER TABLE llx_type_item ADD UNIQUE uk_unique(entity, ref);
