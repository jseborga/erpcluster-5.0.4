ALTER TABLE llx_budget_task ADD INDEX idx_budget_task_fk_budget (fk_budget);
ALTER TABLE llx_budget_task ADD INDEX idx_budget_task_fk_user_creat (fk_user_creat);
ALTER TABLE llx_budget_task ADD INDEX idx_budget_task_fk_user_valid (fk_user_valid);