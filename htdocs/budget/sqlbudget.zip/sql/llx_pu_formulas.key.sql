ALTER TABLE llx_pu_formulas ADD UNIQUE INDEX uk_pformulas_entity_ref(entity,ref);
